import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

class Firestore_Base_DB():
    def __init__(self):
        cred = credentials.Certificate("data/teachme-key.json")
        firebase_admin.initialize_app(cred)
        self.db = firestore.client()